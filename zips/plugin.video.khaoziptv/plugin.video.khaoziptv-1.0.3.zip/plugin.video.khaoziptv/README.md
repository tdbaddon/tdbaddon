This addon was created by PSNDeJKriz
In no way are you allowed to edit customize or change anything
to do with this addon. 
