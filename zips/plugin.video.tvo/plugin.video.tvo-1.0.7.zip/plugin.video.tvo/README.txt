plugin.video.tvo
================

Kodi Addon for TVO.org Video website

Version 1.0.7 website changes and redirect fixes
Version 1.0.6 fix more unicode and scraping issues
Version 1.0.5 fix unicode issues
Version 1.0.4 Website change, added show cache
Version 1.0.3 Added retry and increased timeout for http requests
Version 1.0.2 Subtitle support added
Version 1.0.1 initial release

