plugin.video.foodnetwork
================

Kodi Addon for Food Network website

V3.0.3 bumped t1mlib version
V3.0.2 Cleaned up Isengard
V3.0.1 Separate scraper for future functions
V2.2.1 Initial version
V2.2.2 cleanup for release