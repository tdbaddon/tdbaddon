import xbmcaddon

MainBase = 'http://www.kgroup.tcomputers.ca/@TDBRADIO/TDBRADIO-HOME.xml'
addon = xbmcaddon.Addon('plugin.video.TDBRADIO')