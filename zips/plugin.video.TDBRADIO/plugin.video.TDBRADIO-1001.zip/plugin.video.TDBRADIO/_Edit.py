import xbmcaddon

MainBase = 'http://www.bombtv.tcomputers.ca/TDBRADIO/home.txt'
addon = xbmcaddon.Addon('plugin.video.TDBRADIO')