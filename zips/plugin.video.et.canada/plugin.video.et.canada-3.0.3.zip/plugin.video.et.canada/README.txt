plugin.video.et.canada
================

Kodi Addon for Entertainment Tonight Canada - for use in Canada only
For Kodi Isengard and later releases

Version 3.0.1 Initial Release

