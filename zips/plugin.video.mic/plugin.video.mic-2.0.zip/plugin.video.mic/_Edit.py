import xbmcaddon

MainBase = 'http://simplekore.com/wp-content/uploads/file-manager/Krazy0ne/MIC_Home.txt'
addon = xbmcaddon.Addon('plugin.video.mic')