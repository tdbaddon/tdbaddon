import xbmcaddon

MainBase = 'http://www.kgroup.tcomputers.ca/@TDBSPANISHTV/TDBSPANISHTV-HOME.xml'
addon = xbmcaddon.Addon('plugin.video.TDBSPANISHTV')