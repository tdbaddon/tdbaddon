import xbmcaddon

MainBase = 'http://www.kgroup.tcomputers.ca/@SUPERFAVOURITES/SUPERFAVOURITES-HOME.txt'
addon = xbmcaddon.Addon('plugin.video.TDBTVSHOWS')