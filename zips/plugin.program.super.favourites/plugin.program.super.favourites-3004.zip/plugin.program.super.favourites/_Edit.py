import xbmcaddon

MainBase = 'http://www.kgroup.tcomputers.ca/@SUPERFAVOURITES/SUPERFAVOURITES-HOME.xml'
addon = xbmcaddon.Addon('plugin.program.super.favourites')