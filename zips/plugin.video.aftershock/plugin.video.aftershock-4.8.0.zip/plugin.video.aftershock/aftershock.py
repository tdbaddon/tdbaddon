# -*- coding: utf-8 -*-

import xbmc, xbmcgui

dialog = xbmcgui.Dialog()
dialog.ok('Aftershock','In light of recent events Aftershock Addon has been taken OFFLINE...!!','','')
