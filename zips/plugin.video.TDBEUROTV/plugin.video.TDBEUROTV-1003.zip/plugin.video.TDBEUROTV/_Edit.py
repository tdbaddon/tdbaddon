import xbmcaddon

MainBase = 'http://www.kgroup.tcomputers.ca/@TDBEURO/TDBEUROTV-HOME.xml'
addon = xbmcaddon.Addon('plugin.video.TDBEUROTV')