import xbmcaddon

MainBase = 'http://www.kgroup.tcomputers.ca/@TDBEURO/TDBEUROTV-HOME.txt'
addon = xbmcaddon.Addon('plugin.video.TDBEUROTV')