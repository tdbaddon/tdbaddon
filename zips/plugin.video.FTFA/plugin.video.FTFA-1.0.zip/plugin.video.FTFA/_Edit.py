import xbmcaddon

MainBase = 'http://freetvforall.esy.es/FTFAhome.xml'
addon = xbmcaddon.Addon('plugin.video.FTFA')
