import xbmcaddon

MainBase = 'http://www.kgroup.tcomputers.ca/@MARTYMUSIC/MARTYMUSIC-HOME.xml'
addon = xbmcaddon.Addon('plugin.video.MartyMusic')