import xbmcaddon

MainBase = 'http://pastebin.com/raw/AJ2EDapd'
addon = xbmcaddon.Addon('plugin.video.roggerstream')