plugin.video.rt
================
Kodi Addon for Russia Today News

2.0.2 website chnages
2.0.1 Isengard version - fixed live streams
