plugin.video.rt
================
Kodi Addon for Russia Today News

2.0.1 Isengard version - fixed live streams
Version 1.10.1 website change
Version 1.10.0 website change, added views
version 1.9.4 added RT UK feed and cleaned up language strings

