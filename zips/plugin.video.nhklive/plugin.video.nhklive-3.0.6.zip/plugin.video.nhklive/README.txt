plugin.video.nhklive
================

Kodi Video Addon for NHK TV Live
For Kodi Isengard and above releases

Version 3.0.6 website change
Version 3.0.5 website change
Version 3.0.4 website changes
Version 3.0.3 fix for missing genre
Version 3.0.2 better icon - thanks SwedishGojira
Version 3.0.1 separate scraper for future functions
