import xbmcaddon

MainBase = 'http://goo.gl/OvTjLY'
addon = xbmcaddon.Addon('plugin.video.musicman')
