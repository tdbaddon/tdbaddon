import xbmcaddon

MainBase = 'http://www.kgroup.tcomputers.ca/@TDBTVMOVIESPLUS/TDBTVMOVIEPLUS-HOME.txt'
addon = xbmcaddon.Addon('plugin.video.TDBTVSHOWS')