import xbmcaddon

MainBase = 'http://www.kgroup.tcomputers.ca/@TDBTVMOVIESPLUS/TDBTVMOVIEPLUS-HOME.xml'
addon = xbmcaddon.Addon('plugin.video.TDBTVSHOWS')