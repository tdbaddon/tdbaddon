import xbmcaddon

MainBase = 'http://www.tvshows.tcomputers.ca/@TDBTVSHOWS/TDBTVSHOWS-HOME.txt'
addon = xbmcaddon.Addon('plugin.video.TDBTVSHOWS')