import xbmcaddon

MainBase = 'http://www.tvshows.tcomputers.ca/@TDBTVSHOWS/home.txt'
addon = xbmcaddon.Addon('plugin.video.TDBTVSHOWS')