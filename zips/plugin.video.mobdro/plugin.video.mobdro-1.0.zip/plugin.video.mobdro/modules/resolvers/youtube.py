# -*- coding: utf-8 -*-

def parse_youtube(params):
    return "plugin://plugin.video.youtube/?path=/root/video&action=play_video&videoid=" + params