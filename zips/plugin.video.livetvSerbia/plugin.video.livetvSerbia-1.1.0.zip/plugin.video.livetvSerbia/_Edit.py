import xbmcaddon

MainBase = 'http://bit.ly/2anX5Og'
LSProFile = 'https://dl.dropboxusercontent.com/u/43633303/addon/LSProdynamicCode.py'
addon = xbmcaddon.Addon('plugin.video.livetvSerbia')