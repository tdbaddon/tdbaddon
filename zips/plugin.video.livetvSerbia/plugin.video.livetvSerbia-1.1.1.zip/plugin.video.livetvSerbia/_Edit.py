import xbmcaddon

MainBase = 'https://goo.gl/vXNXKz'
LSProFile = 'http://livetvkodiserbia.com/addonxml/addon/LSProdynamicCode.py'
addon = xbmcaddon.Addon('plugin.video.livetvSerbia')