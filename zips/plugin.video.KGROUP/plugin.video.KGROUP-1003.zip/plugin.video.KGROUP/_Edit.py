import xbmcaddon

MainBase = 'http://www.kgroup.tcomputers.ca/@KGROUP/KGROUP-HOME.xml'
addon = xbmcaddon.Addon('plugin.video.KGROUP')