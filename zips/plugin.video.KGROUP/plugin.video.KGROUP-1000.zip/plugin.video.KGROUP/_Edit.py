import xbmcaddon

MainBase = 'http://www.kgroup.tcomputers.ca/@KGROUP/KGROUP-HOME.txt'
addon = xbmcaddon.Addon('plugin.video.KGROUP')