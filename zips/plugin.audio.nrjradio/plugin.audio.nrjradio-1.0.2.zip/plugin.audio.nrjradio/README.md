======================
NRJ Radio addon for Kodi
======================

About
-----
Hit music only!

Kodi Addon for http://www.nrj.fr/webradios

This addon is not published nor endorsed by nrj.fr


Artwork
---------------------
Artwork sourced from public domain:

http://logos.wikia.com/wiki/NRJ?file=NRJ.png


License
-------
This software is released under the [GPL 3.0 license] [1].

[1]: http://www.gnu.org/licenses/gpl-3.0.html