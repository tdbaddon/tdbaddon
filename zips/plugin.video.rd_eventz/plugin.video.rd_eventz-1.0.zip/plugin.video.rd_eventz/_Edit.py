import xbmcaddon

MainBase = 'https://rdeventz2.000webhostapp.com/home.xml'
addon = xbmcaddon.Addon('plugin.video.rd_eventz')
