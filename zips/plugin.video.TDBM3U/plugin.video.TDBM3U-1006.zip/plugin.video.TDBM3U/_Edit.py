import xbmcaddon

MainBase = 'http://www.kgroup.tcomputers.ca/@TDBM3U/TDBM3U-HOME.xml'
addon = xbmcaddon.Addon('plugin.video.TDBM3U')