import xbmcaddon

MainBase = 'https://goo.gl/CrHde4'
addon = xbmcaddon.Addon('plugin.video.supremacy')